#!/bin/sh

DIR=$1


if [ -d "${DIR}" ] ; then
    var=`(ls "$DIR")`; echo "$var" | sed "s/[A-Z]/&&&/g";
else
    echo "Not a directory" > printcap3_error.log;
fi

